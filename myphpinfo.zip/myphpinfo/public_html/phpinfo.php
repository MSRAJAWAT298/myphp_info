<?php require_once('include/header.php') ?>
<style>
a:link {color: #009; text-decoration: none; background-color: unset !important;}
a:hover {text-decoration: underline;}
</style>
<?php require_once('include/navbar.php') ;
        phpinfo();
?>
<?php require_once('include/footer.php') ?>


      



      


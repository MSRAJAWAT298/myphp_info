<?php require_once('include/header.php') ?>
<style>
body {
    background-image: url('images/php_bg.jpg');
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
}
</style>
<?php require_once('include/navbar.php') ?>
<?php require_once('include/footer.php') ?>


      

